//Write a function here to display "Hello World" on the console

function sayHello() {
  console.log("Hello World");
}

//Write another function here that will delay the execution of the 1st function by 3 seconds
setTimeout(sayHello(), 3000);
