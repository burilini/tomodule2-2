//Write a function here to display "Hello World" on the console

function sayHello() {
  console.log("Hello World");
}

//Write another function here that will print "Hello World" to the console every 3 seconds
setInterval(sayHello(), 3000);
